Question 1: B
Question 2: A