//
//  UploadViewController.swift
//  Pixplore
//
//  Created by Mansi Shah on 4/2/16.
//  Copyright © 2016 Mansi Shah. All rights reserved.
//

import UIKit
import Parse
import AssetsLibrary
import CoreLocation

class UploadViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {
    
    //Image variable
    var tempImage = UIImage()
    
    //User variable
    var currentUser = PFUser.currentUser()?.username
    
    //Location variables
    var userLocation = PFGeoPoint()
    var lat = CLLocationDegrees()
    var lon = CLLocationDegrees()
    
    //Outlet images
    @IBOutlet var uploadImage: UIImageView!
    @IBOutlet var captionTextField: UITextField!
    
    
    @IBAction func backFromUpload(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        //Keyboard resign
        captionTextField.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        getUserLocation()
        calcDistance()
    }
    
    /**
     Resigning the keyboard
     */
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    /**
     Alerts functions
     */
    func displayAlert(title: String, displayError: String) {
        let alert = UIAlertController(title: title, message: displayError, preferredStyle: UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {action in self.dismissViewControllerAnimated(true, completion: nil)}))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func getUserLocation() {
        PFGeoPoint.geoPointForCurrentLocationInBackground {
            (geoPoint: PFGeoPoint?, error: NSError?) -> Void in
            if error == nil {
                self.userLocation = geoPoint!
                print(self.userLocation)
            }
        }
    }
    
    /**
     Posting the picture
     */

    @IBAction func postPicture(sender: AnyObject) {
        var displayError = ""
        if uploadImage == nil {
            displayError = "Please choose a photo."
        }
        if displayError != "" {
            displayAlert("Error in Form", displayError: displayError)
        } else {
            //Picture object
            let picture = PFObject(className: "Photo")
            
            //Adding all fields
            picture["description"] = captionTextField.text
            picture["numberofSaves"] = 0
            picture["location"] = PFGeoPoint(latitude: self.lat, longitude: self.lon)
            picture["username"] = self.currentUser
            
            //Gathering and uploading picture
            let pictureUsed = PFFile(name: "photoUsed.png", data: UIImageJPEGRepresentation(uploadImage.image!, 0.5)!)
            picture["photo"] = pictureUsed
            
            //Saving the picture
            picture.saveInBackgroundWithBlock {
                (success: Bool, error: NSError?) -> Void in
                if (success) {
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
            }
        }
    }
    
    /**
     Picking image and stripping location data
     */
    
    @IBAction func choosePicture(sender: AnyObject) {
        let image = UIImagePickerController()
        image.delegate = self
        image.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
        image.allowsEditing = false
        self.presentViewController(image, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String: AnyObject]) {
        picker.dismissViewControllerAnimated(true, completion: { () in
            if (picker.sourceType == .PhotoLibrary) {
                //self.image = info[UIImagePickerControllerOriginalImage] as! UIImage
                self.uploadImage.image = info[UIImagePickerControllerOriginalImage] as! UIImage
                let library = ALAssetsLibrary()
                let url: NSURL = info[UIImagePickerControllerReferenceURL] as! NSURL
                
                library.assetForURL(url, resultBlock: { (asset: ALAsset!) in
                    if asset.valueForProperty(ALAssetPropertyLocation) != nil {
                        let latitude = (asset.valueForProperty(ALAssetPropertyLocation) as! CLLocation!).coordinate.latitude
                        let longitude = (asset.valueForProperty(ALAssetPropertyLocation) as! CLLocation!).coordinate.longitude
                        self.lat = latitude
                        self.lon = longitude
                        print("\(latitude), \(longitude)")
                    }
                    },
                    failureBlock: { (error: NSError!) in
                        print(error.localizedDescription)
                })
            }
        })
    }
    
    func calcDistance() {
        let userLoc:CLLocation = CLLocation(latitude: self.userLocation.latitude, longitude: self.userLocation.longitude)
        let picLoc:CLLocation = CLLocation(latitude: self.lat, longitude: self.lon)
        let dist:CLLocationDistance = userLoc.distanceFromLocation(picLoc)
        print(dist)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    //Extra functions
    /**func imagePickerController(picker: UIImagePickerController, didFinishPickingImage image: UIImage, editingInfo: [String : AnyObject]?) {
     self.dismissViewControllerAnimated(true, completion: nil)
     uploadImage.image = image
     }*/
    
}
