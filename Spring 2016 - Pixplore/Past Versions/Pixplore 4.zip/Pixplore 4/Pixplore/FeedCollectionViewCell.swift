//
//  FeedCollectionViewCell.swift
//  Pixplore
//
//  Created by Mansi Shah on 4/2/16.
//  Copyright © 2016 Mansi Shah. All rights reserved.
//

import UIKit

class FeedCollectionViewCell: UICollectionViewCell {
    @IBOutlet var locationImage: UIImageView!
    @IBOutlet var profPicture: UIImageView!
    @IBOutlet var userName: UILabel!
    @IBOutlet var numSaves: UILabel!
    @IBOutlet var daysAgoPosted: UILabel!
    @IBOutlet var distance: UILabel!
    @IBOutlet var caption: UILabel!
    
    
}
