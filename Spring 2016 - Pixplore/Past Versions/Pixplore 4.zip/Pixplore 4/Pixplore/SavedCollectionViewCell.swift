//
//  SavedCollectionViewCell.swift
//  Pixplore
//
//  Created by Mansi Shah on 4/9/16.
//  Copyright © 2016 Mansi Shah. All rights reserved.
//

import UIKit

class SavedCollectionViewCell: UICollectionViewCell {
    
}
