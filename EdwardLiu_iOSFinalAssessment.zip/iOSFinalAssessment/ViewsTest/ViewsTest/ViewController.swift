//
//  ViewController.swift
//  ViewsTest
//
//  Created by Virindh Borra on 11/8/15.
//  Copyright © 2015 Virindh Borra. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        /*
        
            For this test you'll implement a basic tab bar view controller. You must implement one tab bar view controller with two distinct sub view controllers. One view controller must show a fully functioning map with the ability to switch between Default, Satellite, AND Hybird map formats. 
        
            The other must implement a fully functioning web browser whose homepage is your favorite search engine.
        
    
        */
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

